# GoIT Node Lessons

## SETUP

- cd final/ open final folder

## Module 3 - Lesson 6: ODM Mongoose

- Mongoose
- Connecting Mongoose
